	<div class="menu">
		<h1><a href="index.php">AVCOE</a></h1>
		<ul>
			<a href="index.php"><li>View</li></a>
			<a href="add.php"><li>Add</li></a>
			<a href="login.php"><li>Logout</li></a>
		</ul>
	</div>