<?php
		session_start();

		if ($_SESSION['user'] == 'teacher') {
			//KEEP
		}
		else{
			//LOGOUT
			header("Location: login.php");
		}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Management System</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>
	<div class="menu">
		<h1><a href="index.php">AVCOE</a></h1>
		<ul>
			<a href="index.php"><li>View</li></a>
			<a href="add.php"><li>Add</li></a>
			<a href="login.php"><li>Logout</li></a>
		</ul>
	</div>
	
	<center>
	<div class="main">
		<br>
		<br>
		<br>
		<br>
<div class="container">
  <h2>Student Records</h2>
  <p>Class BE A</p>
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Roll No</th>
        <th>Name</th>
        <th>Marks</th>
        <th>Attendance</th>
        <th>Mobile</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      	<?php  
      		$servername = "localhost";
			$username = "root";
			$password = "";
			$dbname = "student_records";

			// Create connection
			$conn = new mysqli($servername, $username, $password, $dbname);

			// Check connection
			if ($conn->connect_error) {
			    die("Connection failed: " . $conn->connect_error);
			}

			$sql = "SELECT roll_no,name,marks,attendance,mobile FROM records";
			$result = $conn->query($sql);

			if ($result->num_rows > 0) {
			    // output data of each row
			    while($row = $result->fetch_assoc()) {
			        //echo "id: " . $row["id"]. " - Name: " . $row["name"]. " " . $row["lastname"]. "<br>";
			        echo '<tr><td>'.$row["roll_no"].'</td><td>'.$row["name"].'</td><td>'.$row["marks"].'</td><td>'.$row["attendance"].'</td><td>'.$row["mobile"].'</td><td><a href="delete.php?roll='.$row["roll_no"].'"><button>Delete</button></a></td></tr>';
			    }
			} else {
			    echo "0 results";
			}
			$conn->close();
      	?>
    </tbody>
  </table>
  <form action="upload.php">
  	<input type="submit" value="SEND WHATSAPP MESSAGES">
  </form>
</div>

	</div>
	</center>
</body>
</html>