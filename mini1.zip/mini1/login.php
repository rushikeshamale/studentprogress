<?php
		session_start();
		session_destroy();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Management System</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<style type="text/css">
		input{
			width: 300px;
			padding: 4px;
			margin: 4px;
		}
	</style>
</head>
<body>
	<div class="menu">
		<h1><a href="index.php">AVCOE</a></h1>
	</div>
	<center>
		<div class="main">
			<br>
			<br>
			<br>
			<br>
			<div class="container">
  				<h2>Tutor Login</h2>
  				<p>Class BE A</p>
  				<form action="logged.php" method="Post">
				  	<input type="text" name="user" placeholder="USER NAME" required="yes"><br>
				  	<input type="password" name="password" placeholder="PASSWORD" required="yes"><br>
				  	<input type="submit" name="submit"><br>
  				</form>
			</div>
		</div>
	</center>
</body>
</html>