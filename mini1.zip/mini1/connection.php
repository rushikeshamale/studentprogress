<?php

define('hostname', 'localhost');
define('user', 'root');
define('password', '');
define('databaseName', 'student_records');

$connect = mysqli_connect(hostname, user, password, databaseName);
?>