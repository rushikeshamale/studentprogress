<?php
    session_start();

    if ($_SESSION['user'] == 'teacher') {
      //KEEP
    }
    else{
      //LOGOUT
      header("Location: login.php");
    }


    if (isset($_GET['roll'])) {
      $roll = $_GET['roll'];
      $link = mysqli_connect("localhost", "root", "", "student_records"); 

      if($link === false){ 
        die("ERROR: Could not connect. " . mysqli_connect_error()); 
      } 

      $sql = "DELETE FROM records WHERE roll_no=".$roll;
      if(mysqli_query($link, $sql)){ 
        header("Location: index.php");
      } 
      else{ 
        echo "DATABASE ERROR";
      } 
      mysqli_close($link); 
    }
?>