<?php
		session_start();
		if (isset($_POST['user'])) {
			if ($_POST['user']=="teacher"&&$_POST['password']=="teacher") {
				$_SESSION['user']="teacher";
				header("Location: index.php");
			}
			else{
				header("Location: login.php");
			}
		}
		else {
			if ($_SESSION['user'] == 'teacher') {
				header("Location: index.php");
			}
			else{
				header("Location: login.php");
			}
		}
?>