<?php
		session_start();

		if ($_SESSION['user'] == 'teacher') {
			//KEEP
		}
		else{
			//LOGOUT
			header("Location: login.php");
		}

	if (isset($_POST['roll'])) {
		$roll = $_POST['roll'];
		$name = $_POST['name'];
		$marks = $_POST['marks'];
		$attendance = $_POST['attendance'];
		$mobile = $_POST['mobile'];
		require 'connection.php';
		addStudent($roll,$name,$marks,$attendance,$mobile);
	}

	function addStudent($roll,$name,$marks,$attendance,$mobile)
	{
		global $connect;
		$query = "INSERT INTO `records` (`roll_no`, `name`, `marks`, `attendance`, `mobile`) VALUES ('".$roll."', '".$name."', '".$marks."', '".$attendance."', '".$mobile."')";
		mysqli_query($connect, $query) or die (mysqli_error($connect));
		mysqli_close($connect);
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Student Management System</title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<style type="text/css">
		input{
			width: 300px;
			padding: 4px;
			margin: 4px;
		}
	</style>
</head>
<body>
	<?php 
		include 'menu.php';
	?>
	<center>
	<div class="main">
		<br>
		<br>
		<br>
		<br>
<div class="container">
  <h2>Student Records</h2>
  <p>Class BE A</p>
  <form action="add.php" method="Post">
  	<input type="" name="roll" placeholder="Roll No:" required="yes"><br>
  	<input type="" name="name" placeholder="Name:" required="yes"><br>
  	<input type="" name="marks" placeholder="Marks:" required="yes"><br>
  	<input type="" name="attendance" placeholder="Attendance:" required="yes"><br>
  	<input type="" name="mobile" placeholder="Mobile:" required="yes"><br>
  	<input type="submit" name="submit"><br>
  </form>
</div>

	</div>
	</center>
</body>
</html>