import time
from mysql import connector
from selenium import webdriver
import mysql.connector


def get_number():
    mydb = mysql.connector.connect(host='localhost', user='root', password='', database='student_records')  # replace your values
    mycursor = mydb.cursor()
    query = '''SELECT roll_no, name, marks, attendance, mobile FROM records'''  # Change Query as per your database
    mycursor.execute(query)
    result = mycursor.fetchall()
    return result


def basic():
    path = r'library\chromedriver.exe'  # Download chromedriver.exe file and use path of file here
    driver = webdriver.Chrome(path)
    driver.set_page_load_timeout(10)
    driver.implicitly_wait(10)
    qr = r'http://web.whatsapp.com/'
    driver.get(qr)
    time.sleep(15)
    #result = get_message()
    #result = "Dear%20Parent,%0aThis is to inform you that your ward {} have {}% attendance and secured {}% marks."
    send(driver, get_number())


def send(driver, number):
    total_time = 0
    count = 0
    for i in number:
        time.sleep(7)
        start_time = time.time()
        no = "+91"+i[4]
        name = i[1]
        attendance = i[3]
        marks = i[2]
        msg = '''Dear%20Parent,%0aThis is to inform you that your ward {} have {}% attendance and secured {}% marks.'''.format(name, attendance, marks)
        # msg = message.format(name, attendance, marks)
        #nurl = '''https://wa.me/{}?text={}'''.format(no, msg)
        #nurl = '''https://api.whatsapp.com/send?phone=&text={}&source=&data='''.format(no, msg)
        nurl = '''https://web.whatsapp.com/send?phone={}&text={}&source&data'''.format(no,msg)
        # print(nurl)
        try:
            driver.get(nurl)
        except:
            print("Not Geting url")
        while 1:
            # print("IN FIRST WHILE")
            try:
                #button = driver.find_element_by_id('action-button')
                button = driver.find_element_by_class_name('_3M-N-')
                button.click()
                # print("SEND")
                break
            except Exception:
                # print(Exception)
                time.sleep(0.5)
        # print("OUT FORM FIRST WHILE")
        # while 1:
        #     print("IN 2ND WHILE")
        #     try:
        #         text = 'Phone number shared via url is invalid.'
        #         if text in driver.page_source:
        #             print(text)
        #             break
        #         button = driver.find_element_by_class_name('_35EW6')
        #         button.click()
        #         time.sleep(2)
        #         # while 1:
        #         #     try:
        #         #         element = '''<path fill="#859479" d="M9.75 7.713H8.244V5.359a.5.5 0 0 0-.5-.5H7.65a.5.5 0 0
        #         #         0-.5.5v2.947a.5.5 0 0 0 .5.5h.094l.003-.001.003.002h2a.5.5 0 0 0 .5-.5v-.094a.5.5 0 0
        #         #         0-.5-.5zm0-5.263h-3.5c-1.82 0-3.3 1.48-3.3 3.3v3.5c0 1.82 1.48 3.3 3.3 3.3h3.5c1.82 0
        #         #         3.3-1.48 3.3-3.3v-3.5c0-1.82-1.48-3.3-3.3-3.3zm2 6.8a2 2 0 0 1-2 2h-3.5a2 2 0 0 1-2-2v-3.5a2
        #         #         2 0 0 1 2-2h3.5a2 2 0 0 1 2 2v3.5z"></path> '''
        #         #         driver.find_element(element)
        #         #     except Exception:
        #         #         break
        #         break
        #     except Exception:
        #         time.sleep(0.5)
        #         print(Exception)
        # print("OUT FROM 2ND WHILE")
        exe_time = time.time() - start_time
        total_time = total_time + exe_time
        count += 1
        print("Mobile : {} \nMessage : {} \nTime : {}s\n ".format(no, msg, exe_time))
    time.sleep(5)
    print("AvgTime : {}\n ".format(total_time / count))


basic()
