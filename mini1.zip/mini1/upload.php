<!DOCTYPE html>
<html>
<head>
	<title>Sending Message...</title>
	<meta charset="utf-8">
</head>
<body>
	<h1>Sending Message...</h1>
	<?php 
		// $arr1 = [];
		// $int1 = "";
		// exec("python id.py",$arr1,$int1);

		// $res = NULL;
		// exec("python id.py 2>&1" ,$res); //2>&1 @comments.KEK
		// if(isset($res)){
		//     foreach($res as $rowRes){
		//         echo $rowRes;
		//     }
		// }


		$cmd = 'python send.py';
  		$output = shell_exec($cmd);
  		echo "<pre>$output</pre>";
	?>	
</body>
</html>